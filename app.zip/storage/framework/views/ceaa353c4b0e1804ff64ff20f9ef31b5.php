<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>K Closest Elements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="p-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="mb-4">Find K Closest Elements</h2>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">
                ← Back to Home
            </a>
        </div>

        <form method="POST" action="<?php echo e(route('kclosest')); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label>Enter Sorted Numbers (comma separated):</label>
                <input type="text" name="numbers" class="form-control" placeholder="e.g. 1,2,3,4,5"
                    value="<?php echo e(old('numbers', request('numbers'))); ?>" required>
                <?php $__errorArgs = ['numbers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label>Enter k (how many closest):</label>
                <input type="number" name="k" class="form-control" placeholder="e.g. 4"
                    value="<?php echo e(old('k', request('k'))); ?>" required>
                <?php $__errorArgs = ['k'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label>Enter x (target):</label>
                <input type="number" name="x" class="form-control" placeholder="e.g. 3"
                    value="<?php echo e(old('x', request('x'))); ?>" required>
                <?php $__errorArgs = ['x'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary">Compute</button>
        </form>

        <?php if(isset($result)): ?>
            <div class="alert alert-info mt-4">
                <strong>Question:</strong><br>
                arr = [<?php echo e(implode(', ', $original_nums)); ?>],
                k = <?php echo e($original_k); ?>,
                x = <?php echo e($original_x); ?><br><br>

                <strong>Output:</strong> [<?php echo e(implode(', ', $result)); ?>]
            </div>
        <?php endif; ?>
    </div>
</body>

</html><?php /**PATH C:\Users\bhupe\Desktop\image-upload-task\resources\views/ksort.blade.php ENDPATH**/ ?>