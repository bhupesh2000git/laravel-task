<!DOCTYPE html>
<html lang="en">

<head>
    <title>Image Upload</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .gallery img {
            width: 100%;
            max-width: 200px;
            border-radius: 8px;
        }
    </style>
</head>

<body class="bg-light py-4">

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>📤 Upload Image</h2>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">
                ← Back to Home
            </a>
        </div>


        <div class="container mb-4">
            <div class="row gx-2 gy-2 align-items-end">
                
                <div class="col-12 col-md-8">
                    <form action="<?php echo e(route('images.store')); ?>" method="POST" enctype="multipart/form-data"
                        class="row g-2">
                        <?php echo csrf_field(); ?>

                        <div class="col-12 col-sm-6 col-lg-5">
                            <input type="file" name="image" class="form-control" required accept="image/*">
                        </div>

                        <div class="col-12 col-sm-4 col-lg-4">
                            <select name="orientation" class="form-select" required>
                                <option value="">Orientation</option>
                                <option value="portrait">Portrait</option>
                                <option value="landscape">Landscape</option>
                            </select>
                        </div>

                        <div class="col-12 col-sm-2 col-lg-3 d-grid">
                            <button type="submit" class="btn btn-success">
                                Upload
                            </button>
                        </div>
                    </form>
                </div>

                
                <div class="col-12 col-md-4">
                    <form action="<?php echo e(route('images.clear')); ?>" method="POST" class="d-grid">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger"
                            onclick="return confirm('Are you sure you want to delete ALL images?');">
                            Clear All
                        </button>
                    </form>
                </div>
            </div>
        </div>


        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <hr>

        <h4 class="mb-3">🖼 Uploaded Images</h4>
        <div class="row gallery">
            <?php
                $total = count($images);
                $index = 0;
            ?>

            <div class="row">

                <?php if($total > 0): ?>
                                <?php
                                    $first = $images[0];
                                ?>

                                
                                <?php if($first->orientation === 'landscape'): ?>
                                    
                                    <?php while($index < $total): ?>
                                        
                                        <?php if(isset($images[$index]) && $images[$index]->orientation === 'landscape'): ?>
                                            <div class="col-md-12 mb-3">
                                                <div class="card p-2">
                                                    <img src="<?php echo e(asset('storage/' . $images[$index]->filename)); ?>" class="img-fluid" alt=""
                                                        width="100%">
                                                    <p class="text-center mt-2"><?php echo e(ucfirst($images[$index]->orientation)); ?></p>
                                                </div>
                                            </div>
                                            <?php $index++; ?>
                                        <?php endif; ?>

                                        
                                        <?php for($i = 0; $i < 2; $i++): ?>
                                            <?php if(isset($images[$index]) && $images[$index]->orientation === 'portrait'): ?>
                                                <div class="col-md-6 mb-3">
                                                    <div class="card p-2">
                                                        <img src="<?php echo e(asset('storage/' . $images[$index]->filename)); ?>" class="img-fluid" alt=""
                                                            width="100%">
                                                        <p class="text-center mt-2"><?php echo e(ucfirst($images[$index]->orientation)); ?></p>
                                                    </div>
                                                </div>
                                                <?php $index++; ?>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    <?php endwhile; ?>

                                <?php else: ?>
                                    
                                    <?php while($index < $total): ?>
                                        <?php if(isset($images[$index]) && $images[$index]->orientation === 'portrait'): ?>
                                            <div class="col-md-6 mb-3">
                                                <div class="card p-2">
                                                    <img src="<?php echo e(asset('storage/' . $images[$index]->filename)); ?>" class="img-fluid" alt=""
                                                        width="100%">
                                                    <p class="text-center mt-2"><?php echo e(ucfirst($images[$index]->orientation)); ?></p>
                                                </div>
                                            </div>
                                            <?php $index++; ?>
                                        <?php endif; ?>

                                        <?php if(isset($images[$index]) && $images[$index]->orientation === 'landscape'): ?>
                                            <div class="col-md-12 mb-3">
                                                <div class="card p-2">
                                                    <img src="<?php echo e(asset('storage/' . $images[$index]->filename)); ?>" class="img-fluid" alt=""
                                                        width="100%">
                                                    <p class="text-center mt-2"><?php echo e(ucfirst($images[$index]->orientation)); ?></p>
                                                </div>
                                            </div>
                                            <?php $index++; ?>
                                        <?php endif; ?>
                                    <?php endwhile; ?>
                                <?php endif; ?>

                <?php else: ?>
                    <p>No images uploaded yet.</p>
                <?php endif; ?>

            </div>

        </div>
    </div>

</body>

</html><?php /**PATH C:\Users\bhupe\Desktop\image-upload-task\resources\views/images/index.blade.php ENDPATH**/ ?>